public class TestFizzBuzz {
    public static void main(String[] args){
        FizzBuzz test = new FizzBuzz();

        String a = test.fizzBuzz(3);
        String b = test.fizzBuzz(5);
        String c = test.fizzBuzz(15);
        String d = test.fizzBuzz(2);

        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);
    }
}
                  