public class calculadora {
    public static double calcularHipotenusa (double catA, double catB){
       double hipotenusa ;
       hipotenusa =  Math.sqrt((catA*catA)+(catB*catB));
       return hipotenusa;
    }
}
