public class holaJava {

    public static void main(String[] args) {
        String nombre = "Cristian";
        Integer edad = 24;
        String ciudad = "Capital Federal, Arg";
        
        System.out.println("Mi nombre es " + nombre);
        System.out.println("Tengo " + edad);
        System.out.println("Mi ciudad es " + ciudad);
    }
}